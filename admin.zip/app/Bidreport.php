<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bidreport extends Model
{
    protected $table='bidreport';
    protected $primaryKey ='bidid';
    public $timestamps=false;
}
