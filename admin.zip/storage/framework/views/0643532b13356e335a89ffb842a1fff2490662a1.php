<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\Art Gallery\admin\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>