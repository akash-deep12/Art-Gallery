
<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left mt-3">
                <h2>Feedbacks</h2>
            </div>
        </div>
</div>
    <?php if($errors->any()): ?>
		<div class="alert alert-danger">
		<strong>Warning!</strong> Please check your input code<br><br>
			<ul>
				 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					 <li><?php echo e($error); ?></li>
				 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			 </ul>
		</div>
	<?php endif; ?>
   <div class="container-fluid table-responsive">
    <table class="table table-bordered mt-3">
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Message</th>
            <th width="200px">Action</th>
        </tr>
        <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
              <td><?php echo e($feedback->id); ?></td>
            <td><?php echo e($feedback->name); ?></td>
            <td><?php echo e($feedback->message); ?></td>
            <td>
                <form action="<?php echo e(route('feedbacks.destroy',$feedback->id)); ?>" method="POST">
    
                
                    	<a class="btn btn-primary btn-sm" href="<?php echo e(route('feedbacks.show', $feedback->id)); ?>"><i class="fa fa-eye"></i> Show</a>
							  
				
                    <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#exampleModal">
						 <i class="fa fa-trash"></i> Delete 
						</button>

						<!-- Modal -->
						<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
						  <div class="modal-dialog" role="document">
						    <div class="modal-content">
						      <div class="modal-header">
						        <h5 class="modal-title" id="exampleModalLabel">Confirmation</h5>
						        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						          <span aria-hidden="true">&times;</span>
						        </button>
						      </div>
						      <div class="modal-body">
						        <p>Are You Sure to Delete This Message</p>
						      </div>
						      <div class="modal-footer">
						        <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal"><i class="fa fa-window-close"></i> Close</button>
								        <?php echo csrf_field(); ?>
		                    		<?php echo method_field('DELETE'); ?>
		      
		                   				 <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Delete</button>
						      </div>
						    </div>
						  </div>
						</div>
                </form>
            </td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    </div>
     <?php echo $feedbacks->links(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Art Gallery\admin\resources\views/feedbacks/index.blade.php ENDPATH**/ ?>