
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12 margin-tb">
		<div class="pull-left mt-3">
			<h5>Product Details</h5>
		</div>
		<div class="pull-right mt-3">
			<a class="btn btn-success btn-sm" href="<?php echo e(route('products.index')); ?>"><i class="fa fa-arrow-circle-left"></i> Back</a>
		</div>
	</div>
</div>
<div class="container-fluid mt-3 ">
	<div class="jumbotron">
		<div class="row">
			<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12" style="font-size: 22px;">
				<div class="col-xs-12 col-sm-12 col-md-12" >
					<div class="form-group">
						<strong>Title:</strong>
						<?php echo e($product->prod_name); ?>

					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Category:</strong>
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($category->category_id == $product->category_id): ?>
						<?php echo e($category->category_name); ?>

						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Description:</strong>
						<?php echo e($product->prod_description); ?>

					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>End Date:</strong>
						<?php echo e($product->due_date); ?>

					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Starting Bid:</strong>
						$<?php echo e($product->starting_bid); ?>

					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Artist:</strong>
						<?php echo e($product->artist); ?>

					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Highest Bidder:</strong>
						<?php if(isset($highestBidder[0])): ?>
						<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($user->id == $highestBidder[0]->bidder): ?>
						<?php echo e($user->name); ?>

						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Highest Bid:</strong>
						<?php if(isset($highestBidder[0])): ?>
						
						<?php echo e(($highestBidder[0]->bidamount)); ?>

						<?php endif; ?>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Status:</strong>
						<?php if(isset($highestBidder[0])): ?>
						
						<?php if($highestBidder[0]->status == 0): ?>
						Active
						<?php else: ?>
						Expired
						<?php endif; ?>
						<?php endif; ?>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Bid Log: </strong>
						<button type="button" class="btn btn-info btn-sm " data-toggle="modal" data-target="#bidlog">
						Click</button>
					</div>
				</div>
				
			</div>
			<div class="col-lg-8 col-md-12">
				<div class="col-xs-12 col-sm-12 col-md-12 col-sm-12 col-xs-12">
					<div class="form-group">
						
						<img src="<?php echo e(asset('public/images/'.$product->prod_image)); ?>"  class="img-fluid" />
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="bidlog" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="font-size: 12px;">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title center" id="exampleModalLabel">
					
				</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				 <center><h5><?php echo e($product->prod_name); ?> Bidding Log</h5></center>
                           <div class="container-fluid table-responsive">
                    <table id="demoTable" class="table table-lg ">
        <thead>
                <tr>
                        <th sort="index">Bidder</th>
                        <th sort="date">Date of Bid Placed</th>
                        <th sort="description">Amount</th>
                        
                </tr>
        </thead>

           <tbody>
         
          				<?php $__currentLoopData = $bidlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bidlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          				 <tr>
                        <td><?php echo e($bidlog->name); ?></td>
                        <td><?php echo e($bidlog->biddatetime); ?></td>
                        <td><?php echo e($bidlog->bidamount); ?></td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
      </table>
    </div>
			</div>
			<img src="<?php echo e(asset('images/1.jpg')); ?>">
		</div>
	</div>
	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Art Gallery\admin\resources\views/products/show.blade.php ENDPATH**/ ?>