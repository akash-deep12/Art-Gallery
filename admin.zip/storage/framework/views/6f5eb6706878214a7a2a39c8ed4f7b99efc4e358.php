<?php $__env->startSection('content'); ?>

<div class="row">
			<div class="container col">
				<div class="card bg-info text-light mt-3">
  				<div class="card-body">
  					<h4>Finished Auctions</h4>

   					<h1 class="ml-2"><?php echo e($finished); ?> <i class="fa fa-hourglass-end fa-2x pull-right" style="opacity: 50%;"></i></h1>

  				</div>
  				<div class="card-footer text-center"><a href="<?php echo e(route('finished')); ?>"> More Info <i class="fa fa-arrow-circle-right fa-lg"></i></a></div>
				</div>
			</div>
			<div class="container col">
				<div class="card bg-warning text-light mt-3">
  				<div class="card-body">
  					<h4>Users</h4>
   					<h1 class="ml-2"><?php echo e($users_count); ?><i class="fa fa-users fa-2x pull-right" style="opacity: 50%;"></i> </h1>
  				</div>
  				<div class="card-footer text-center"><a href="<?php echo e(route('users.index')); ?>"> More Info <i class="fa fa-arrow-circle-right fa-lg"></i></a></div>
			</div>
		</div>
			<div class="container col">
				<div class="card bg-danger text-light mt-3">
  				<div class="card-body">
  					<h4>Feedbacks</h4>
   					<h1 class="ml-2"><?php echo e($feedback_count); ?><i class="fa fa-comments fa-2x pull-right" style="opacity: 50%;"></i> </h1>
  				</div>
  				<div class="card-footer text-center"><a href="<?php echo e(route('feedbacks.index')); ?>"> More Info <i class="fa fa-arrow-circle-right fa-lg"></i></a></div>
				</div>
			</div>
</div>
                    <div class="container mt-3">
	  				  <div class="row">
	       				 <div class="col">
	          				  <div class="card">
	               				<div class="card-body">

	                  		  <h1><?php echo e($chart1->options['chart_title']); ?></h1>
	                  		  <?php echo $chart1->renderHtml(); ?>


	                			</div>

	            		    </div>
	        			</div>
	    				</div>
					</div>
					<div class="container mt-3">
	  				  <div class="row">
	       				 <div class="col-md-8">
	          				  <div class="card">
	               				<div class="card-body">

	                  		  <h1><?php echo e($chart2->options['chart_title']); ?></h1>
	                  		  <?php echo $chart2->renderHtml(); ?>


	                			</div>

	            		    </div>
	        			</div>
	    				</div>
					</div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js" charset="utf-8"></script>
    		<?php echo $chart1->renderChartJsLibrary(); ?>

			<?php echo $chart1->renderJs(); ?>

			<?php echo $chart2->renderChartJsLibrary(); ?>

			<?php echo $chart2->renderJs(); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Art Gallery\admin\resources\views/home.blade.php ENDPATH**/ ?>