<?php echo e($slot); ?>

<?php /**PATH C:\wamp64\www\Art Gallery\admin\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>