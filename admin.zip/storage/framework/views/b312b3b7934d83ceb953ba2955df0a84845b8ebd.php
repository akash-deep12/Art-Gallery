
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb mt-3">
        <div class="pull-left mt-3">
            <h2>Edit Category</h2>
        </div>
        <div class="pull-right mt-3">
            <a class="btn btn-success btn-sm" href="<?php echo e(route('categories.index')); ?>"><i class="fa fa-arrow-circle-left"></i> Back</a>
        </div>
    </div>
</div>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <strong>Warning!</strong> Please check input field code<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<form action="<?php echo e(route('categories.update',$category->category_id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="container-fluid jumbotron mt-3">
        <div class="row justify-content-center">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Category Name</strong>
                    <input type="text" name="category_name" class="form-control form-control-sm"  value="<?php echo e($category->category_name); ?>">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-check-square"></i> Submit</button>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Art Gallery\admin\resources\views/categories/edit.blade.php ENDPATH**/ ?>