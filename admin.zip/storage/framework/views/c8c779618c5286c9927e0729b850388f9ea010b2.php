
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    
                    <div class="container bg-light border mt-3">   
                    <h4 class="mt-3">Users</h4>
                    <?php echo $productChart->container(); ?>

                    </div>

</div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js" charset="utf-8"></script>
          <?php echo $productChart->script(); ?>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Art Gallery\admin\resources\views/charts.blade.php ENDPATH**/ ?>