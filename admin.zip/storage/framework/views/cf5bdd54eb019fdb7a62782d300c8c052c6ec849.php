
<?php $__env->startSection('content'); ?>
<div class="container-fluid row mt-3">	
	<?php $__currentLoopData = $finishedAuctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $finishedAuction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="container justify-center border col-md-5 col-sm-12 col-xs-12 p-0 m-1"><p class="text-center text-dark border-bottom p-2"><span class="text-danger">Winner</span>
	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($user->id == $finishedAuction->bidder): ?>
	<?php echo e($user->name); ?>

	<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</p> 
		<div class="container text-center mb-3">

		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($product->product_id == $finishedAuction->productid): ?>
		<img src="<?php echo e(asset('public/images/'.$product->prod_image)); ?>" class="img-thumbnail"/>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


		</div>
		<div class="container text-center border-top">
			<p class="text-info p-0 m-0"><span class="text-danger">Sold:</span>
				<?php echo e($finishedAuction->bidamount); ?>

			</p>
			<p class="text-info p-0 m-0"><span class="text-danger">Artist:</span>
				<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($product->product_id==$finishedAuction->productid): ?>
				<?php echo e($product->artist); ?>

				<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</p>	
		</div>



	 </div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Art Gallery\admin\resources\views/finished/index.blade.php ENDPATH**/ ?>