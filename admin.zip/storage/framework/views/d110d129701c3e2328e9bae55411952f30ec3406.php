
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="container mt-3">
	<h3><span class="text-info">Database Name: </span><?php echo e(App\Http\Controllers\DataController::databaseName()); ?><button class="btn btn-success btn-sm pull-right">Create New Table</button></h3>
	</div>
<div class="row justify-content-center">
       
                 <div class="card">
                      <div class="card-header bg-dark text-light text-justify">
                            <strong>Tables</strong>
                      </div>
                  <div class="card-body">
                  	<?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                   <i class="fa fa-check-square"></i> <?php echo e($table); ?>

                   <a href="<?php echo e(route('showTable',$table)); ?>" class="btn-sm btn-warning">Show</a>
                        </div>
                    </div>
                    <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Art Gallery\admin\resources\views/database/index.blade.php ENDPATH**/ ?>